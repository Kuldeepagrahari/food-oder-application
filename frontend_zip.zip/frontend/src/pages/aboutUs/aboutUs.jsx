import React from 'react'
import "./aboutUS.css"
const AboutUs = () => {
  return (
    <div className='about-us'>
      <h1> OUR MOTO </h1>
      
    </div>
  )
}

export default AboutUs
